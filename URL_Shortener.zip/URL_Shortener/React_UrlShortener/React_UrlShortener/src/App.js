
import './App.css';
import React, { useState } from 'react';
import axios from 'axios';
import {Container , Form, Button} from 'react-bootstrap';

const App = () =>{
  const [originalUrl, setOriginalUrl] = useState('');
  const [shortUrl, setShortUrl] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const[expiredAt, setExpiredAt] = useState(false);

  const generateShortUrl = () => {
    const shorterUrl = 'https://www.google.com';
    const creationTime = new Date();
    return {shorterUrl, creationTime};
  }
 

  const handleShortenUrl = async () => {
    try {
      const response = await axios.post('http://localhost:8080/api/shorten', {originalUrl});
      setShortUrl(response.data);
     setErrorMessage('');
    } catch (error) {
    setShortUrl('');
      if (error.response) {
        setErrorMessage(error.response.data);
      } else {
        setErrorMessage('An error occurred');
      }
     
    }
  };

  const handleVisitUrl = async () => {
    try {
      const response = await axios.get(shortUrl);
      window.location.href = response.data; // Redirect the user to the original long URL
    } catch (error) {
      console.error('Error redirecting to long URL:', error);
    }
  };

  const handleUrlClick = () => {
    const {shorterUrl, creationTime } = generateShortUrl();
    const currentTime = new Date();
    const timeDiff = (currentTime-creationTime)/(1000 * 60);
    if(timeDiff <= 5){
      window.location.href = shorterUrl;
    }
    else { 
      setExpiredAt(true);
    }
  };
 
  
  return (
    <Container>
      <h1>Link Shortener</h1>
      <Form>
        <Form.Group>
          <Form.Control
          type="text"
          value={originalUrl}
          onChange={(e) => setOriginalUrl(e.target.value)}
          placeholder="Enter URL"
          />
        </Form.Group>
     
      <Button variant = "primary" onClick={handleShortenUrl}>Shorten URL</Button>
      </Form>
      {shortUrl && (
        <div>
          <h3>Shortened URL: </h3>
          <a href={shortUrl} target="_blank" rel="noopener noreferrer"
           onClick={handleVisitUrl}>{shortUrl}</a>
          </div>
      )}
      <div>
        <Button onClick = {handleUrlClick}> click to visit shorter URL</Button>
        {expiredAt && <p>Url has expired</p>}
      </div>
      </Container>
  );
};

export default App;
