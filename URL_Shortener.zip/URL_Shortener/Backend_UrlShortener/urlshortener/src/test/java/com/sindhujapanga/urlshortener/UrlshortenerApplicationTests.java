package com.sindhujapanga.urlshortener;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UrlshortenerApplicationTests {

	@Test
	void contextLoads() {
	}

}
