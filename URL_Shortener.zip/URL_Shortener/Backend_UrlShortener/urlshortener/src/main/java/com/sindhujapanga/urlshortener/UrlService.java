package com.sindhujapanga.urlshortener;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.UUID;

@Service
public class UrlService {
    private final UrlRepository urlRepository;

    @Autowired
    public UrlService(UrlRepository urlRepository) {
        this.urlRepository = urlRepository;
    }

    public String shortenUrl(String originalUrl) {
        // Check if the URL already exists in the database
        UrlEntity existingMapping = urlRepository.findByOriginalUrl(originalUrl);
        if (existingMapping != null) {
            return existingMapping.getShortUrl();
        }

        // Generate a new short URL
        String shortUrl = generateShortUrl();

        // Create a new mapping and save it to the database
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime expiresAt = now.plusMinutes(5);

        UrlEntity newMapping = new UrlEntity();
        newMapping.setOriginalUrl(originalUrl);
        newMapping.setShortUrl(shortUrl);
        newMapping.setCreatedAt(now);
        newMapping.setExpiresAt(expiresAt);

        urlRepository.save(newMapping);

        return shortUrl;
    }

    public String generateShortUrl() {
        return "http://localhost:7070/" + UUID.randomUUID().toString().substring(0, 8);
    }

    public String getOriginalUrl(String shortUrl) {
        UrlEntity mapping = urlRepository.findByShortUrl(shortUrl);

        if (mapping == null) {
            return null;
        }

        // Check if the URL is expired
        LocalDateTime now = LocalDateTime.now();
        if (mapping.getExpiresAt().isBefore(now)) {
            return "expired";
        }

        return mapping.getOriginalUrl();
    }
}

