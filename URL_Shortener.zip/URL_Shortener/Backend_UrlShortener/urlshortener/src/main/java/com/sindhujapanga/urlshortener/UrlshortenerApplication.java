package com.sindhujapanga.urlshortener;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.FilterType;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;


//@EnableMongoRepositories(basePackageClasses = UrlRepository.class)
//@EnableJpaRepositories(excludeFilters =
//@ComponentScan.Filter(type = FilterType.ASSIGNABLE_TYPE, value = UrlRepository.class))
@SpringBootApplication
public class UrlshortenerApplication {


	public static void main(String[] args) throws IOException {

		SpringApplication.run(UrlshortenerApplication.class, args);
	}

}
