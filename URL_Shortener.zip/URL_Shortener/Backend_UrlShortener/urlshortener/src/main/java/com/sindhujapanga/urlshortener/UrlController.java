package com.sindhujapanga.urlshortener;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
@CrossOrigin
@RestController
@RequestMapping("/api")

public class UrlController {

    private final UrlService urlService;
    @Autowired
    public UrlController(UrlService urlService) {
        this.urlService = urlService;
    }

    @PostMapping("/shorten")
    public ResponseEntity<String> shortenUrl(@RequestBody String originalUrl) {
        String shortUrl = urlService.shortenUrl(originalUrl);
        return ResponseEntity.ok(shortUrl);
    }
    
    @GetMapping("/{shortUrl}")
    public ResponseEntity<String> redirectToOriginalUrl(@PathVariable String shortUrl) {
        String originalUrl = urlService.getOriginalUrl
                (shortUrl);

        if (originalUrl == null) {
            return ResponseEntity.notFound().build();
        } else if (originalUrl.equals("expired")) {
            return ResponseEntity.badRequest().body("URL has expired");
        } else {
            return ResponseEntity.ok(originalUrl);
        }
    }
}
